
window.bg_sprites = [

    { "id": 0, "name": "lemon",         "w": 107, "h": 110, "x": 0,   "y": 0},
    { "id": 1, "name": "star",          "w": 107, "h": 110, "x": 107,   "y": 0 },
    { "id": 2, "name": "cherry",        "w": 107, "h": 110, "x": 214,   "y": 0 },
    { "id": 3, "name": "wmelon",        "w": 107, "h": 110, "x": 321,   "y": 0 },
    { "id": 4, "name": "grape",         "w": 107, "h": 110, "x": 428,   "y": 0 },
    { "id": 5, "name": "seven",         "w": 107, "h": 110, "x": 535,   "y": 0 },
    { "id": 6, "name": "plum",          "w": 107, "h": 110, "x": 642,   "y": 0 },
    { "id": 7, "name": "orange",        "w": 107, "h": 110, "x": 749,   "y": 0 },
    
];
